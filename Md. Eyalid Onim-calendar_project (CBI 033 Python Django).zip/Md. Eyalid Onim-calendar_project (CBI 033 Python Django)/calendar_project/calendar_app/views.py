from rest_framework import viewsets
from .models import Event
from django.shortcuts import render
from .serializers import EventSerializer
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response

from rest_framework.permissions import AllowAny

class EventViewSet(viewsets.ModelViewSet):
    queryset = Event.objects.all()
    serializer_class = EventSerializer
    permission_classes = [AllowAny]  # Allow both authenticated and anonymous users

    def perform_create(self, serializer):
        if self.request.user.is_authenticated:
            # Assign the event to the authenticated user
            serializer.save(user=self.request.user)
        else:
            # Handle case for anonymous user
            serializer.save(user=None)  # Or handle it another way, e.g., using a default user
    


def calendar_view(request):
    return render(request, 'calendar.html')

@api_view(['GET', 'POST', 'DELETE'])
@permission_classes([AllowAny])  # Allow anyone to access this view
def event_list(request):
    if request.method == 'GET':
        events = Event.objects.all()
        serializer = EventSerializer(events, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = EventSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

    elif request.method == 'DELETE':
        event = Event.objects.get(pk=request.data['id'])  # Assume you're passing 'id' in the request
        event.delete()
        return Response(status=204)
    # Handle POST and other methods...